SIBTAIN ALI — N8N PORTFOLIO WEBSITE

FILES
- index.html: portfolio homepage with search and category filters
- workflows/: 10 sanitized n8n workflow JSON downloads

GITHUB PAGES SETUP
1. Extract this ZIP.
2. Open your GitHub repository (the one used for GitHub Pages).
3. Upload index.html, README.txt, and the workflows folder contents while preserving the workflows folder.
4. Commit the changes.
5. Wait for GitHub Pages to rebuild, then refresh your portfolio URL.

IMPORTANT PRIVACY NOTE
Credentials, webhook IDs, pinned sample data and some personal identifiers were removed/replaced. Still review the files before publishing. Imported workflows require you to reconnect your own credentials and review node settings before use.
